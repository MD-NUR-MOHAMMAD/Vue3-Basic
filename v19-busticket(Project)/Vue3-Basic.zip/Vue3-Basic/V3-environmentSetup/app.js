var app = Vue.createApp({
    data() {
        return {
            title: 'welcome Bangla Tutorials'
        }
    }
});

app.mount('#app')