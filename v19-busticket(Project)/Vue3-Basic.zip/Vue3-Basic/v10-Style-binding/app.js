var app = Vue.createApp({
  data() {
    return {
      textColor: "white",
      bgColor: "green"
    };
  },
  methods: {
  }
});

app.mount("#app");
